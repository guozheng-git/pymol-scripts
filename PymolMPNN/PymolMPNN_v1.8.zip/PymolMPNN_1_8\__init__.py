from .mpnn_numpy import ProteinMPNNNumpy, ALPHABET


def __init_plugin__(app=None):
    """PyMOL Plugin Manager entry point."""
    from .plugin import register, show_dialog
    from pymol import cmd
    register(cmd)
    try:
        from pymol.plugins import addmenuitemqt
        addmenuitemqt("PymolMPNN 1.8", show_dialog)
    except Exception:
        pass

__all__ = ["ProteinMPNNNumpy", "ALPHABET"]
