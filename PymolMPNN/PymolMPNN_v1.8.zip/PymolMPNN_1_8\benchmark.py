from __future__ import annotations

import time
from pathlib import Path
import numpy as np

from .mpnn_numpy import ProteinMPNNNumpy


def benchmark(weights, golden_dir):
    model = ProteinMPNNNumpy(weights)
    for path in sorted(Path(golden_dir).glob("*_v48_020.npz")):
        z = np.load(path)
        t0 = time.perf_counter()
        result = model.design(z["input.X"], chain_encoding=z["input.chain_encoding"],
                              residue_idx=z["input.residue_idx"], mask=z["input.mask"],
                              chain_mask=z["input.chain_M"])
        dt = time.perf_counter() - t0
        print(f"{path.name}\tL={z['input.mask'].shape[1]}\t{dt:.4f}s")
        if "sample.S" in z and not np.array_equal(result["S"], z["sample.S"]):
            raise AssertionError(f"sequence mismatch: {path}")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--weights", required=True)
    p.add_argument("--golden", required=True)
    a = p.parse_args()
    benchmark(a.weights, a.golden)
