"""NumPy implementation of the full-backbone ProteinMPNN edge features."""
from __future__ import annotations

import numpy as np


def _linear(x, weight, bias=None):
    y = np.matmul(x, weight.T)
    return y if bias is None else y + bias


def _layer_norm(x, weight, bias, eps=1e-5):
    mean = np.mean(x, axis=-1, keepdims=True, dtype=np.float32)
    var = np.mean((x - mean) ** 2, axis=-1, keepdims=True, dtype=np.float32)
    return (x - mean) / np.sqrt(var + np.float32(eps)) * weight + bias


def gelu(x):
    """Vectorized approximation of Torch's default exact GELU.

    The Abramowitz-Stegun erf approximation has maximum scalar error around
    1.5e-7 and avoids Python-level element iteration.
    """
    z = x / np.float32(1.4142135623730951)
    sign = np.sign(z)
    a = np.abs(z)
    t = np.float32(1.0) / (np.float32(1.0) + np.float32(0.3275911) * a)
    poly = (((((np.float32(1.061405429) * t + np.float32(-1.453152027)) * t
               + np.float32(1.421413741)) * t + np.float32(-0.284496736)) * t
             + np.float32(0.254829592)) * t)
    erf = sign * (np.float32(1.0) - poly * np.exp(-(a * a)))
    return np.float32(0.5) * x * (np.float32(1.0) + erf)


def virtual_cb(x):
    b = x[:, :, 1] - x[:, :, 0]
    c = x[:, :, 2] - x[:, :, 1]
    a = np.cross(b, c)
    return (np.float32(-0.58273431) * a + np.float32(0.56802827) * b
            - np.float32(0.54067466) * c + x[:, :, 1])


def _gather_scalar(edges, indices):
    return np.take_along_axis(edges, indices, axis=2)


def _dist(ca, mask, top_k):
    mask_2d = mask[:, None, :] * mask[:, :, None]
    dx = ca[:, None, :, :] - ca[:, :, None, :]
    d = mask_2d * np.sqrt(np.sum(dx * dx, axis=-1, dtype=np.float32)
                         + np.float32(1e-6))
    d_max = np.max(d, axis=-1, keepdims=True)
    adjusted = d + (np.float32(1.0) - mask_2d) * d_max
    k = min(top_k, ca.shape[1])
    idx = np.argsort(adjusted, axis=-1, kind="stable")[..., :k]
    neighbors = np.take_along_axis(adjusted, idx, axis=-1)
    return neighbors.astype(np.float32, copy=False), idx.astype(np.int64)


def _rbf(d, count=16):
    mu = np.linspace(np.float32(2.0), np.float32(22.0), count,
                     dtype=np.float32).reshape(1, 1, 1, count)
    sigma = np.float32(20.0 / count)
    return np.exp(-((d[..., None] - mu) / sigma) ** 2).astype(np.float32)


def _pair_rbf(a, b, idx):
    delta = a[:, :, None, :] - b[:, None, :, :]
    d = np.sqrt(np.sum(delta * delta, axis=-1, dtype=np.float32)
                + np.float32(1e-6))
    return _rbf(_gather_scalar(d, idx))


def protein_features(x, mask, residue_idx, chain_labels, weights, top_k=48):
    """Return the official v_48 full-backbone edge embedding and KNN indices."""
    x = np.asarray(x, dtype=np.float32)
    mask = np.asarray(mask, dtype=np.float32)
    residue_idx = np.asarray(residue_idx, dtype=np.int64)
    chain_labels = np.asarray(chain_labels, dtype=np.int64)
    n, ca, c, o = x[:, :, 0], x[:, :, 1], x[:, :, 2], x[:, :, 3]
    cb = virtual_cb(x)
    d_neighbors, e_idx = _dist(ca, mask, top_k)
    pairs = [
        (ca, ca), (n, n), (c, c), (o, o), (cb, cb),
        (ca, n), (ca, c), (ca, o), (ca, cb),
        (n, c), (n, o), (n, cb), (cb, c), (cb, o), (o, c),
        (n, ca), (c, ca), (o, ca), (cb, ca),
        (c, n), (o, n), (cb, n), (c, cb), (o, cb), (c, o),
    ]
    rbf = [_rbf(d_neighbors)]
    rbf.extend(_pair_rbf(a, b, e_idx) for a, b in pairs[1:])
    rbf_all = np.concatenate(rbf, axis=-1)

    offset = residue_idx[:, :, None] - residue_idx[:, None, :]
    offset = _gather_scalar(offset, e_idx)
    same_chain = (chain_labels[:, :, None] == chain_labels[:, None, :]).astype(np.int64)
    same_chain = _gather_scalar(same_chain, e_idx)
    clipped = np.clip(offset + 32, 0, 64) * same_chain + (1 - same_chain) * 65
    onehot = np.eye(66, dtype=np.float32)[clipped.astype(np.int64)]
    positional = _linear(onehot, weights["features.embeddings.linear.weight"],
                         weights["features.embeddings.linear.bias"])
    raw = np.concatenate((positional, rbf_all), axis=-1)
    edge = _linear(raw, weights["features.edge_embedding.weight"])
    edge = _layer_norm(edge, weights["features.norm_edges.weight"],
                       weights["features.norm_edges.bias"])
    return edge.astype(np.float32, copy=False), e_idx
