﻿"""Minimal PyMOL command/plugin shell for the NumPy runtime."""
from __future__ import annotations

from pathlib import Path
import numpy as np

from .mpnn_numpy import ProteinMPNNNumpy
from .pymol_adapter import (extract_backbone, selection_mask, write_b_factors,
                             write_sequence, write_fasta, mutate_changed_residues)


_DESIGN_CALLBACK = None
ALPHABET = "ACDEFGHIKLMNPQRSTVWYX"


def _clean_arg(value):
    """Remove quotes retained by PyMOL's extended-command parser."""
    value = str(value).strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        value = value[1:-1].strip()
    return value


def _parse_global_bias(text):
    """Parse ``A=0.5,K=-1`` into a 21-vector in ProteinMPNN alphabet order."""
    text = _clean_arg(text) if text else ""
    values = np.zeros(len(ALPHABET), dtype=np.float32)
    if not text:
        return values
    for item in text.replace(";", ",").split(","):
        item = item.strip()
        if not item:
            continue
        try:
            aa, value = item.split("=", 1)
            aa = aa.strip().upper()
            if len(aa) != 1 or aa not in ALPHABET:
                raise ValueError
            values[ALPHABET.index(aa)] = float(value)
        except Exception as exc:
            raise ValueError(f"Invalid global bias item '{item}', expected A=0.5,K=-1") from exc
    return values


def _parse_residue_bias(text, data):
    """Parse ``1:A=0.5;A:42:K=-1`` into an [1,L,21] bias array.

    The first form addresses the extracted sequence index (1-based); the
    second addresses a PyMOL chain/resi pair.
    """
    values = np.zeros((1, len(data["keys"]), len(ALPHABET)), dtype=np.float32)
    text = _clean_arg(text) if text else ""
    if not text:
        return values
    key_to_index = {(k[2], str(k[3])): i for i, k in enumerate(data["keys"])}
    for group in text.split(";"):
        group = group.strip()
        if not group:
            continue
        head, *items = group.split(":")
        if not items:
            raise ValueError(f"Invalid residue bias group '{group}'")
        if head.isdigit():
            index = int(head) - 1
            assignments = ":".join(items)
        else:
            if len(items) < 2:
                raise ValueError(f"Invalid residue bias group '{group}'")
            index = key_to_index.get((head, str(items[0])))
            assignments = ":".join(items[1:])
            if index is None:
                raise ValueError(f"Residue '{head}:{items[0]}' not found in selection")
        if index is None or not 0 <= index < values.shape[1]:
            raise ValueError(f"Residue index out of range in '{group}'")
        for item in assignments.replace(";", ",").split(","):
            aa, number = item.split("=", 1)
            aa = aa.strip().upper()
            if len(aa) != 1 or aa not in ALPHABET:
                raise ValueError(f"Unknown amino acid in residue bias '{item}'")
            values[0, index, ALPHABET.index(aa)] = float(number)
    return values


def register(cmd, weights_path=None):
    global _DESIGN_CALLBACK
    root = Path(__file__).resolve().parent
    if weights_path:
        runtimes = {"vanilla": ProteinMPNNNumpy(Path(weights_path))}
    else:
        runtimes = {
            "vanilla": ProteinMPNNNumpy(root / "weights" / "mpnn_v48_020.npz"),
            "soluble": ProteinMPNNNumpy(root / "weights" / "soluble_v48_020.npz"),
        }

    def design(selection="all", output_object="mpnn_design", fixed_selection="",
               temperature=0.0, seed=0, pdb_path="", fasta_path="",
               omit_aas="", bias="", bias_by_res="", model="vanilla"):
        selection = _clean_arg(selection)
        output_object = _clean_arg(output_object)
        fixed_selection = _clean_arg(fixed_selection)
        model = (_clean_arg(model) or "vanilla").lower()
        aliases = {"default": "vanilla", "proteinmpnn": "vanilla",
                   "solublempnn": "soluble"}
        model = aliases.get(model, model)
        if model not in runtimes:
            raise ValueError("Unknown model '%s'; choose vanilla or soluble" % model)
        runtime = runtimes[model]
        data = extract_backbone(cmd, selection)
        fixed = selection_mask(cmd, data["keys"], fixed_selection) if fixed_selection else None
        global_bias = _parse_global_bias(bias)
        residue_bias = _parse_residue_bias(bias_by_res, data)
        result = runtime.design(data["backbone"], chain_encoding=data["chain_encoding"],
                                residue_idx=data["residue_idx"], fixed_mask=fixed,
                                native_sequence=data["sequence"], temperature=float(temperature),
                                seed=int(seed), omit_aas=omit_aas,
                                bias=global_bias, bias_by_res=residue_bias)
        seq = runtime.decode_sequence(result["S"])
        cmd.create(output_object, selection)
        mutations = [(i + 1, key[2], key[3], old, new)
                     for i, (key, old, new) in enumerate(
                         zip(data["keys"], data["sequence"], seq)) if old != new]
        changed, mutation_failures = mutate_changed_residues(
            cmd, output_object, data["keys"], data["sequence"], seq)
        write_sequence(cmd, output_object, data["keys"], seq)
        write_b_factors(cmd, f"{output_object} and polymer.protein",
                        result["probs"].max(axis=-1)[0], object_name=output_object)
        report = [
            f"PymolMPNN design ({model}): {seq}",
            f"Selected residues: {data['total_residues']}; model residues: {len(seq)}; "
            f"fixed residues: {int(fixed.sum()) if fixed is not None else 0}; "
            f"sequence changes: {len(mutations)}",
        ]
        print(report[0])
        print(report[1])
        if data["skipped"]:
            report.append(f"Skipped residues ({len(data['skipped'])}):")
            print(report[-1])
            for key, resn, reason in data["skipped"][:20]:
                line = f"  {key[2] or '_'}:{key[3]} {resn}: {reason}"
                report.append(line); print(line)
        report.append("Changed positions (sequence_index chain:resi old>new):")
        print(report[-1])
        for index, chain, resi, old, new in mutations:
            line = f"  {index} {chain or '_'}:{resi} {old}>{new}"
            report.append(line); print(line)
        pdb_path = _clean_arg(pdb_path) if pdb_path else str(Path.cwd() / f"{output_object}.pdb")
        fasta_path = (_clean_arg(fasta_path) if fasta_path else
                      str(Path(pdb_path).with_suffix(".fasta")))
        cmd.save(pdb_path, output_object, state=1)
        loaded_name = f"{output_object}_pdb"
        cmd.delete(loaded_name)
        cmd.load(pdb_path, loaded_name, state=1)
        write_fasta(cmd, output_object, fasta_path)
        report.append(f"Mutagenesis rebuilt {changed} changed residues")
        print(report[-1])
        if mutation_failures:
            report.append(f"Mutagenesis failures ({len(mutation_failures)}):")
            print(report[-1])
            for chain, resi, old, new, reason in mutation_failures:
                line = f"  {chain or '_'}:{resi} {old}>{new}: {reason}"
                report.append(line); print(line)
        report.append(f"Saved PDB: {pdb_path}")
        report.append(f"Saved FASTA: {fasta_path}")
        print(report[-2]); print(report[-1])
        design._last_report = "\n".join(report)
        return seq

    cmd.extend("mpnn_design", design)
    cmd.extend("mpnn_design_v12", design)
    cmd.extend("mpnn_design_v14", design)
    cmd.extend("mpnn_design_v15", design)
    cmd.extend("mpnn_design_v17", design)
    cmd.extend("mpnn_design_v18", design)
    _DESIGN_CALLBACK = design
    return design


def show_dialog():
    from pymol import cmd
    from pymol.Qt import QtWidgets

    dialog = QtWidgets.QDialog()
    dialog.setWindowTitle("PymolMPNN 1.8")
    form = QtWidgets.QFormLayout(dialog)
    selection = QtWidgets.QLineEdit("")
    selection.setPlaceholderText("chain A")
    fixed = QtWidgets.QLineEdit("")
    fixed.setPlaceholderText("resi 1-100")
    output = QtWidgets.QLineEdit("mpnn_design")
    model = QtWidgets.QComboBox()
    model.addItem("Vanilla ProteinMPNN", "vanilla")
    model.addItem("SolubleMPNN", "soluble")
    temperature = QtWidgets.QDoubleSpinBox(); temperature.setRange(0.0, 5.0)
    temperature.setSingleStep(0.1); temperature.setValue(0.0)
    seed = QtWidgets.QSpinBox(); seed.setRange(0, 2147483647)
    omit = QtWidgets.QLineEdit("")
    omit.setPlaceholderText("C P")
    bias = QtWidgets.QLineEdit("")
    bias.setPlaceholderText("A=0.5,K=-1.0")
    bias_res = QtWidgets.QLineEdit("")
    bias_res.setPlaceholderText("A:42:V=-1.0;A:57:K=0.8")
    run = QtWidgets.QPushButton("Design")
    show_all = QtWidgets.QPushButton("Show full result")
    output_box = QtWidgets.QPlainTextEdit()
    output_box.setReadOnly(True)
    output_box.setPlaceholderText("Design result will appear here")
    output_box.setFixedHeight(120)
    status = QtWidgets.QLabel("")
    for label, widget in (("Selection", selection), ("Fixed selection", fixed),
                          ("Output object", output), ("Model", model),
                          ("Temperature", temperature),
                          ("Seed", seed), ("Omit AAs", omit),
                          ("Global bias", bias), ("Residue bias", bias_res)):
        form.addRow(label, widget)
    form.addRow("", run)
    form.addRow("Result", output_box)
    show_all_row = QtWidgets.QHBoxLayout()
    show_all_row.addWidget(show_all)
    show_all_row.addStretch(1)
    form.addRow("", show_all_row)
    form.addRow(status)

    def show_full_result():
        text = getattr(_DESIGN_CALLBACK, "_last_report", "No design result yet.")
        full = QtWidgets.QDialog(dialog)
        full.setWindowTitle("PymolMPNN 1.8 - Full design result")
        layout = QtWidgets.QVBoxLayout(full)
        viewer = QtWidgets.QPlainTextEdit(); viewer.setReadOnly(True); viewer.setPlainText(text)
        layout.addWidget(viewer)
        full.resize(760, 560)
        full.show()
        show_full_result._dialog = full

    def execute():
        try:
            status.setText("Running ProteinMPNN and rebuilding side chains...")
            QtWidgets.QApplication.processEvents()
            if _DESIGN_CALLBACK is None:
                raise RuntimeError("Plugin design callback is not registered")
            main_selection = selection.text().strip() or "polymer.protein"
            fixed_text = fixed.text().strip()
            # A short GUI expression such as `resi 1-100` is understood within
            # the main selection, avoiding accidental matches in other objects.
            fixed_selection = (f"({main_selection}) and ({fixed_text})"
                               if fixed_text else "")
            result = _DESIGN_CALLBACK(main_selection, output.text().strip(),
                                      fixed_selection, temperature.value(),
                                      seed.value(), "", "", omit.text().strip(),
                                      bias.text().strip(), bias_res.text().strip(),
                                      model.currentData())
            full_report = getattr(_DESIGN_CALLBACK, "_last_report", result)
            # Store the complete report while keeping the widget itself compact.
            output_box.setPlainText(full_report)
            output_box.verticalScrollBar().setValue(0)
            preview = result if len(result) <= 50 else result[:47] + "..."
            status.setText(f"Done: {len(result)} residues\n{preview}")
        except Exception as exc:
            status.setText(f"Error: {type(exc).__name__}: {exc}")

    run.clicked.connect(execute)
    show_all.clicked.connect(show_full_result)
    dialog.resize(520, 430)
    dialog.show()
    # Keep a reference because Qt otherwise may garbage-collect the dialog.
    show_dialog._dialog = dialog
    return dialog

