"""Dependency-light ProteinMPNN runtime (NumPy only)."""
from __future__ import annotations

from pathlib import Path
import numpy as np

from .features import protein_features
from .network import incremental_argmax


ALPHABET = "ACDEFGHIKLMNPQRSTVWYX"
ALPHABET_INDEX = {aa: i for i, aa in enumerate(ALPHABET)}


class ProteinMPNNNumpy:
    def __init__(self, weights_path: str | Path):
        self.weights_path = Path(weights_path)
        # NpzFile keeps the underlying ZIP open when used lazily. On Windows
        # that prevents PyMOL's Plugin Manager from updating or uninstalling
        # the plugin. Copy all tensors into memory and close the archive now.
        with np.load(self.weights_path, allow_pickle=False) as archive:
            self.weights = {name: archive[name].copy() for name in archive.files}

    def design(self, backbone, *, chain_encoding=None, residue_idx=None,
               mask=None, chain_mask=None, fixed_mask=None,
               native_sequence=None, seed=0, temperature=0.0,
               omit_aas="", bias=None, bias_by_res=None):
        """Design a sequence from [B,L,4,3] or [L,4,3] backbone coordinates.

        `mask` is 1 for valid residues. `chain_mask` is 1 for positions to
        redesign. `fixed_mask` is 1 for positions forced to remain unchanged.
        """
        x = np.asarray(backbone, dtype=np.float32)
        if x.ndim == 3:
            x = x[None]
        b, length = x.shape[:2]
        if chain_encoding is None:
            chain_encoding = np.ones((b, length), dtype=np.int64)
        if residue_idx is None:
            residue_idx = np.broadcast_to(np.arange(length, dtype=np.int64),
                                          (b, length)).copy()
        if mask is None:
            mask = np.ones((b, length), dtype=np.float32)
        if chain_mask is None:
            chain_mask = np.ones((b, length), dtype=np.float32)
        if fixed_mask is not None:
            chain_mask = chain_mask * (1.0 - np.asarray(fixed_mask, dtype=np.float32))
        if native_sequence is None:
            s_true = np.zeros((b, length), dtype=np.int64)
        elif isinstance(native_sequence, str):
            if len(native_sequence) != length:
                raise ValueError("native_sequence length does not match backbone")
            s_true = np.array([[ALPHABET.index(a) for a in native_sequence]], dtype=np.int64)
        else:
            s_true = np.asarray(native_sequence, dtype=np.int64)
        omit_mask = None
        if omit_aas:
            if not isinstance(omit_aas, str):
                raise TypeError("omit_aas must be a string such as 'C P'")
            tokens = omit_aas.replace(",", " ").split()
            # Also accept compact syntax such as 'CDE'.
            letters = "".join(tokens).upper()
            bad = sorted(set(letters) - set(ALPHABET))
            if bad:
                raise ValueError(f"Unknown amino acid(s) in omit_aas: {''.join(bad)}")
            if len(set(letters)) == len(ALPHABET):
                raise ValueError("omit_aas cannot exclude all 21 alphabet symbols")
            omit_mask = np.zeros((b, length, len(ALPHABET)), dtype=bool)
            for aa in letters:
                omit_mask[:, :, ALPHABET_INDEX[aa]] = True
        bias_vec = None if bias is None else np.asarray(bias, dtype=np.float32)
        if bias_vec is not None:
            if bias_vec.shape != (len(ALPHABET),):
                raise ValueError("bias must have 21 values in ALPHABET order")
        bias_res = None if bias_by_res is None else np.asarray(bias_by_res, dtype=np.float32)
        if bias_res is not None:
            if bias_res.ndim == 2:
                bias_res = bias_res[None]
            if bias_res.shape != (b, length, len(ALPHABET)):
                raise ValueError("bias_by_res must have shape [L,21] or [B,L,21]")
        # Deterministic order is useful for reproducible PyMOL operations.
        order = np.broadcast_to(np.arange(length, dtype=np.int64), (b, length)).copy()
        edge, e_idx = protein_features(x, mask, residue_idx, chain_encoding,
                                        self.weights, top_k=48)
        rng = np.random.default_rng(seed)
        return incremental_argmax(edge, e_idx, mask, chain_mask, np.ones_like(chain_mask),
                                  s_true, order, self.weights,
                                  temperature=temperature, rng=rng,
                                  omit_mask=omit_mask, bias=bias_vec,
                                  bias_by_res=bias_res)

    @staticmethod
    def decode_sequence(indices):
        return "".join(ALPHABET[int(i)] for i in np.asarray(indices).ravel())
