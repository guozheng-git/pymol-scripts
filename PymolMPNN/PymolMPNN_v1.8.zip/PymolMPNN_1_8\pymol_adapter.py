"""PyMOL coordinate extraction and result mapping."""
from __future__ import annotations

from collections import OrderedDict
import numpy as np


BACKBONE = ("N", "CA", "C", "O")
AA3_TO_1 = {
    "ALA":"A", "ARG":"R", "ASN":"N", "ASP":"D", "CYS":"C",
    "GLN":"Q", "GLU":"E", "GLY":"G", "HIS":"H", "ILE":"I",
    "LEU":"L", "LYS":"K", "MET":"M", "PHE":"F", "PRO":"P",
    "SER":"S", "THR":"T", "TRP":"W", "TYR":"Y", "VAL":"V",
}
AA1_TO_3 = {v: k for k, v in AA3_TO_1.items()}


def extract_backbone(cmd, selection="polymer.protein", state=1):
    protein_model = cmd.get_model(f"({selection}) and polymer.protein", state=state)
    all_keys = OrderedDict()
    for atom in protein_model.atom:
        key = (atom.model, getattr(atom, "segi", ""), atom.chain,
               getattr(atom, "resi", ""), getattr(atom, "ins_code", ""))
        all_keys.setdefault(key, {"resn": atom.resn, "atoms": set()})
        all_keys[key]["atoms"].add(atom.name)
    model = cmd.get_model(f"({selection}) and name N+CA+C+O", state=state)
    residues = OrderedDict()
    for atom in model.atom:
        if atom.name not in BACKBONE or atom.resn not in AA3_TO_1:
            continue
        key = (atom.model, getattr(atom, "segi", ""), atom.chain,
               getattr(atom, "resi", ""), getattr(atom, "ins_code", ""))
        if key not in residues:
            residues[key] = {"resn": atom.resn, "atoms": {}}
        # Prefer blank/A altloc; reject duplicate selected conformers.
        if atom.name not in residues[key]["atoms"] or getattr(atom, "alt", "") in ("", "A"):
            residues[key]["atoms"][atom.name] = np.asarray(atom.coord, dtype=np.float32)
    rows = []
    for key, value in residues.items():
        missing = [a for a in BACKBONE if a not in value["atoms"]]
        if missing:
            raise ValueError(f"Missing backbone atoms {missing} at {key}")
        rows.append((key, value["resn"], np.stack([value["atoms"][a] for a in BACKBONE])))
    if not rows:
        raise ValueError("Selection contains no complete standard-protein backbone residues")
    accepted = {r[0] for r in rows}
    skipped = []
    for key, value in all_keys.items():
        if key not in accepted:
            missing = [a for a in BACKBONE if a not in value["atoms"]]
            reason = ("non-standard residue" if value["resn"] not in AA3_TO_1
                      else "missing " + "/".join(missing))
            skipped.append((key, value["resn"], reason))
    x = np.stack([r[2] for r in rows], axis=0)
    chains = [r[0][2] or "_" for r in rows]
    chain_names = {c: i + 1 for i, c in enumerate(dict.fromkeys(chains))}
    chain_encoding = np.array([chain_names[c] for c in chains], dtype=np.int64)[None, :]
    residue_idx = np.empty((1, len(rows)), dtype=np.int64)
    for i, c in enumerate(chains):
        residue_idx[0, i] = 100 * (chain_names[c] - 1) + sum(1 for q in chains[:i] if q == c)
    return {
        "backbone": x[None], "chain_encoding": chain_encoding,
        "residue_idx": residue_idx, "sequence": "".join(AA3_TO_1[r[1]] for r in rows),
        "chains": chains, "keys": [r[0] for r in rows],
        "total_residues": len(all_keys), "skipped": skipped,
    }


def selection_mask(cmd, keys, selection, state=1):
    """Map an arbitrary PyMOL selection to the extracted residue ordering."""
    if not selection:
        return np.zeros((1, len(keys)), dtype=np.float32)
    selected = cmd.get_model(f"({selection}) and polymer.protein", state=state)
    selected_keys = {
        (a.model, getattr(a, "segi", ""), a.chain, getattr(a, "resi", ""),
         getattr(a, "ins_code", "")) for a in selected.atom
    }
    return np.array([[1.0 if key in selected_keys else 0.0 for key in keys]],
                    dtype=np.float32)


def write_b_factors(cmd, selection, values, state=1, object_name=None):
    """Write per-residue values to all atoms in a copied result object."""
    selected = cmd.get_model(f"({selection})", state=state)
    vals = np.asarray(values, dtype=float).ravel()
    mapping = {}
    for atom in selected.atom:
        key = (getattr(atom, "segi", ""), atom.chain,
               getattr(atom, "resi", ""), getattr(atom, "ins_code", ""))
        mapping.setdefault(key, len(mapping))
    if len(mapping) != len(vals):
        raise ValueError(f"Value count {len(vals)} does not match residues {len(mapping)}")
    target = object_name or selection
    model = cmd.get_model(target, state=state)
    for atom in model.atom:
        key = (getattr(atom, "segi", ""), atom.chain,
               getattr(atom, "resi", ""), getattr(atom, "ins_code", ""))
        if key in mapping:
            atom.b = float(vals[mapping[key]])
    cmd.delete(target)
    cmd.load_model(model, target, state=state)


def write_sequence(cmd, object_name, keys, sequence, state=1):
    """Write designed one-letter sequence back as PyMOL three-letter resn."""
    model = cmd.get_model(object_name, state=state)
    if len(keys) != len(sequence):
        raise ValueError("Sequence length does not match extracted residues")
    key_to_resn = {
        (getattr(key, "segi", ""), key[2], key[3], key[4]): AA1_TO_3[aa]
        for key, aa in zip(keys, sequence)
    }
    for atom in model.atom:
        k = (getattr(atom, "segi", ""), atom.chain,
             getattr(atom, "resi", ""), getattr(atom, "ins_code", ""))
        if k in key_to_resn:
            atom.resn = key_to_resn[k]
    cmd.delete(object_name)
    cmd.load_model(model, object_name, state=state)


def write_fasta(cmd, object_name, path):
    fasta = cmd.get_fastastr(object_name)
    from pathlib import Path
    Path(path).write_text(fasta, encoding="ascii")
    return fasta


def mutate_changed_residues(cmd, object_name, keys, native_sequence, designed_sequence):
    """Rebuild changed side chains with PyMOL's Mutagenesis rotamer library."""
    changed = 0
    failures = []
    wizard = None
    for key, old, new in zip(keys, native_sequence, designed_sequence):
        if old == new:
            continue
        chain, resi = key[2], key[3]
        target = "_mpnn_mut_target"
        chain_expr = f"chain {chain}" if chain else "chain ''"
        try:
            if wizard is None:
                cmd.wizard("mutagenesis")
                wizard = cmd.get_wizard()
            cmd.select(target, f"{object_name} and {chain_expr} and resi {resi}")
            if cmd.count_atoms(target) == 0:
                raise ValueError("target residue not found")
            wizard.set_mode(AA1_TO_3[new])
            wizard.do_select(target)
            wizard.apply()
            observed = cmd.get_fastastr(
                f"{object_name} and {chain_expr} and resi {resi}")
            observed = "".join(line.strip() for line in observed.splitlines()
                               if not line.startswith(">"))
            if observed == new:
                changed += 1
            else:
                raise ValueError(f"mutation not applied (observed {observed or 'none'})")
        except Exception as exc:
            # Remove the incompatible native side chain. write_sequence() will
            # set the intended resn, leaving an honest backbone-only residue.
            cmd.remove(f"{object_name} and {chain_expr} and resi {resi} and "
                       "not name N+CA+C+O+OXT")
            failures.append((chain, resi, old, new, str(exc) or type(exc).__name__))
            # Reset only after a failed operation; successful mutations keep
            # reusing the same wizard for speed.
            cmd.set_wizard()
            wizard = None
        finally:
            cmd.delete(target)
    cmd.set_wizard()
    return changed, failures
