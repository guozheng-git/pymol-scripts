# PymolMPNN 1.8 — NumPy PyMOL plugin

This prototype runs the official full-backbone `v_48_020` model without
PyTorch. It requires only the Python/NumPy runtime already bundled with the
target PyMOL installation.

## PyMOL usage

From the PyMOL command line, after importing/registering the plugin:

```text
mpnn_design obj1, mpnn_result
mpnn_design obj1, mpnn_fixed, obj1 and resi 1-10
mpnn_design obj1, mpnn_sample, , 0.2, 7

# Omit amino acids, apply global bias, and apply per-residue bias
mpnn_design obj1, mpnn_constrained, , 0.0, 0, , , "C P", "A=0.5,K=-0.5", "1:A=1.0;A:42:V=-1.0"

# Select the bundled SolubleMPNN weights (the final argument is model)
mpnn_design obj1, mpnn_soluble, , 0.0, 0, , , , , , soluble
```

PyMOL commands conventionally use comma-separated positional arguments. The
plugin also strips accidental outer quotes retained by some PyMOL versions.

The output object is a copy of the input structure. Unchanged residues retain
their native side chains; changed residues are rebuilt automatically through
PyMOL's Mutagenesis rotamer library. ProteinMPNN predicts residue identities,
not unique side-chain chi angles, so the selected rotamer is a PyMOL packing
choice. Per-residue maximum amino-acid probability is written to B-factors.

Each run also saves a new PDB and FASTA, then loads the PDB as
`<output_object>_pdb`. The input object and input file are never overwritten.

This first release supports standard residues with complete N/CA/C/O atoms.
Non-standard residues and incomplete backbone records raise an explicit error.

Temperature `0` is deterministic argmax. Positive temperatures use NumPy's
PCG64 generator; sampled sequences are statistically comparable to Torch but
are not expected to be bitwise identical for the same integer seed.

Constraint syntax:

* `omit_aas`: compact or space/comma separated amino acids, for example `C P`.
* `bias`: comma-separated global logit offsets in alphabet notation, for example `A=0.5,K=-1`.
* `bias_by_res`: semicolon-separated groups. Use a 1-based extracted sequence
  index (`1:A=1.0`) or a PyMOL chain/residue (`A:42:V=-1.0`).
* `model`: `vanilla` (default) or `soluble`. This is the final optional command
  argument so existing command lines remain compatible.

The GUI shows a compact result report and provides a `Show full result` button
for the complete sequence, changed positions, failures, and output paths.
