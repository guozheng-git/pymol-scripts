"""NumPy encoder primitives for the official full-backbone ProteinMPNN."""
from __future__ import annotations

import numpy as np

from .features import _layer_norm, _linear, gelu


def gather_nodes(nodes, idx):
    b = np.arange(nodes.shape[0])[:, None, None]
    return nodes[b, idx]


def gather_edges(edges, idx):
    b = np.arange(edges.shape[0])[:, None, None]
    return edges[b, np.arange(edges.shape[1])[None, :, None], idx]


def cat_neighbors_nodes(h_nodes, h_neighbors, idx):
    return np.concatenate((h_neighbors, gather_nodes(h_nodes, idx)), axis=-1)


def encoder_layer(h_v, h_e, e_idx, mask, mask_attend, w, layer):
    p = f"encoder_layers.{layer}."
    h_ev = cat_neighbors_nodes(h_v, h_e, e_idx)
    h_v_expand = h_v[:, :, None, :]
    h_ev = np.concatenate((np.broadcast_to(h_v_expand, h_ev.shape[:-1] + (h_v.shape[-1],)), h_ev), axis=-1)
    msg = _linear(gelu(_linear(gelu(_linear(h_ev, w[p+"W1.weight"], w[p+"W1.bias"])),
                               w[p+"W2.weight"], w[p+"W2.bias"])),
                  w[p+"W3.weight"], w[p+"W3.bias"])
    msg *= mask_attend[..., None]
    dh = np.sum(msg, axis=2) / np.float32(30.0)
    h_v = _layer_norm(h_v + dh, w[p+"norm1.weight"], w[p+"norm1.bias"])
    dh = _linear(gelu(_linear(h_v, w[p+"dense.W_in.weight"], w[p+"dense.W_in.bias"])),
                 w[p+"dense.W_out.weight"], w[p+"dense.W_out.bias"])
    h_v = _layer_norm(h_v + dh, w[p+"norm2.weight"], w[p+"norm2.bias"])
    h_v *= mask[..., None]
    h_ev = cat_neighbors_nodes(h_v, h_e, e_idx)
    h_v_expand = h_v[:, :, None, :]
    h_ev = np.concatenate((np.broadcast_to(h_v_expand, h_ev.shape[:-1] + (h_v.shape[-1],)), h_ev), axis=-1)
    msg = _linear(gelu(_linear(gelu(_linear(h_ev, w[p+"W11.weight"], w[p+"W11.bias"])),
                               w[p+"W12.weight"], w[p+"W12.bias"])),
                  w[p+"W13.weight"], w[p+"W13.bias"])
    h_e = _layer_norm(h_e + msg, w[p+"norm3.weight"], w[p+"norm3.bias"])
    return h_v, h_e


def encoder(h_e_input, e_idx, mask, weights):
    h_v = np.zeros((h_e_input.shape[0], h_e_input.shape[1], 128), dtype=np.float32)
    h_e = _linear(h_e_input, weights["W_e.weight"], weights["W_e.bias"])
    mask_attend = gather_nodes(mask[..., None], e_idx)[..., 0] * mask[..., None]
    trace = {}
    for layer in range(3):
        h_v, h_e = encoder_layer(h_v, h_e, e_idx, mask, mask_attend, weights, layer)
        trace[f"encoder_layers.{layer}.h_V"] = h_v.copy()
        trace[f"encoder_layers.{layer}.h_E"] = h_e.copy()
    return h_v, h_e, trace


def decoder_layer(h_v, h_e, mask_v, w, layer):
    p = f"decoder_layers.{layer}."
    h_v_expand = np.broadcast_to(h_v[:, :, None, :],
                                 h_e.shape[:-1] + (h_v.shape[-1],))
    h_ev = np.concatenate((h_v_expand, h_e), axis=-1)
    msg = _linear(gelu(_linear(gelu(_linear(h_ev, w[p+"W1.weight"],
                                                    w[p+"W1.bias"])),
                               w[p+"W2.weight"], w[p+"W2.bias"])),
                  w[p+"W3.weight"], w[p+"W3.bias"])
    dh = np.sum(msg, axis=2) / np.float32(30.0)
    h_v = _layer_norm(h_v + dh, w[p+"norm1.weight"], w[p+"norm1.bias"])
    dh = _linear(gelu(_linear(h_v, w[p+"dense.W_in.weight"],
                              w[p+"dense.W_in.bias"])),
                 w[p+"dense.W_out.weight"], w[p+"dense.W_out.bias"])
    h_v = _layer_norm(h_v + dh, w[p+"norm2.weight"], w[p+"norm2.bias"])
    return h_v * mask_v[..., None]


def _decoding_masks(order, e_idx, mask):
    """Build official backward/forward masks from a decoding permutation."""
    batch, length = order.shape
    rank = np.empty_like(order)
    positions = np.arange(length, dtype=order.dtype)[None, :]
    np.put_along_axis(rank, order, np.broadcast_to(positions, order.shape), axis=1)
    b = np.arange(batch)[:, None, None]
    neighbor_rank = rank[b, e_idx]
    center_rank = rank[:, :, None]
    backward = (neighbor_rank < center_rank).astype(np.float32)[..., None]
    mask_1d = mask[:, :, None, None]
    return mask_1d * backward, mask_1d * (np.float32(1.0) - backward)


def incremental_argmax(edge, e_idx, mask, chain_mask, chain_m_pos,
                       s_true, decoding_order, weights, temperature=0.0,
                       rng=None, omit_mask=None, bias=None, bias_by_res=None):
    """Official incremental decoder; temperature=0 selects deterministic argmax."""
    h_v, h_e, enc_trace = encoder(edge, e_idx, mask, weights)
    chain_mask = chain_mask * chain_m_pos * mask
    mask_bw, mask_fw = _decoding_masks(decoding_order, e_idx, mask)
    batch, length = mask.shape
    h_s = np.zeros_like(h_v)
    sequence = np.zeros((batch, length), dtype=np.int64)
    probs_all = np.zeros((batch, length, 21), dtype=np.float32)
    h_v_stack = [h_v.copy()] + [np.zeros_like(h_v) for _ in range(3)]

    h_ex_encoder = cat_neighbors_nodes(np.zeros_like(h_s), h_e, e_idx)
    h_exv_encoder = cat_neighbors_nodes(h_v, h_ex_encoder, e_idx)
    h_exv_encoder_fw = mask_fw * h_exv_encoder
    trace = dict(enc_trace)
    b = np.arange(batch)
    for step in range(length):
        t = decoding_order[:, step]
        idx_t = e_idx[b, t][:, None, :]
        h_e_t = h_e[b, t][:, None, :, :]
        h_es_t = cat_neighbors_nodes(h_s, h_e_t, idx_t)
        enc_t = h_exv_encoder_fw[b, t][:, None, :, :]
        mask_t = mask[b, t][:, None]
        bw_t = mask_bw[b, t][:, None, :, :]
        for layer in range(3):
            h_esv_decoder = cat_neighbors_nodes(h_v_stack[layer], h_es_t, idx_t)
            h_v_t = h_v_stack[layer][b, t][:, None, :]
            h_esv_t = bw_t * h_esv_decoder + enc_t
            h_new = decoder_layer(h_v_t, h_esv_t, mask_t, weights, layer)
            h_v_stack[layer + 1][b, t] = h_new[:, 0]
            trace[f"decoder.{step:04d}.{layer}.h_V"] = h_new.copy()
        logits = _linear(h_v_stack[-1][b, t], weights["W_out.weight"],
                         weights["W_out.bias"])
        # Apply the same post-network constraints used by the reference
        # implementation: omit masks are hard exclusions and biases are
        # additive logit offsets.  Fixed positions still use S_true below.
        if omit_mask is not None:
            logits = np.where(omit_mask[b, t, :], -np.inf, logits)
        if bias is not None:
            logits = logits + bias[None, :]
        if bias_by_res is not None:
            logits = logits + bias_by_res[b, t, :]
        shifted = logits - np.max(logits, axis=-1, keepdims=True)
        probs = np.exp(shifted).astype(np.float32)
        probs /= np.sum(probs, axis=-1, keepdims=True)
        if temperature and temperature > 0:
            scaled = logits / np.float32(temperature)
            scaled -= np.max(scaled, axis=-1, keepdims=True)
            probs = np.exp(scaled).astype(np.float32)
            probs /= np.sum(probs, axis=-1, keepdims=True)
            if rng is None:
                rng = np.random.default_rng(0)
            sampled = np.array([rng.choice(21, p=p) for p in probs], dtype=np.int64)
        else:
            sampled = np.argmax(probs, axis=-1).astype(np.int64)
        design = chain_mask[b, t] > 0.5
        selected = np.where(design, sampled, s_true[b, t])
        sequence[b, t] = selected
        probs_all[b, t] = probs * chain_mask[b, t, None]
        h_s[b, t] = weights["W_s.weight"][selected]
        trace[f"decoder.{step:04d}.logits"] = logits.copy()
    return {"S": sequence, "probs": probs_all,
            "decoding_order": decoding_order.copy(), "trace": trace}
